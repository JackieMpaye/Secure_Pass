<?php
session_start();


include('settings/connection.php'); // Use forward slashes in the 




if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Something was posted
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the user is logged in
    $user_data = check_login(); // Call check_login function from functions.php

    if ($user_data !== null && isset($user_data['username'])) {
        // Proceed with accessing $user_data['username'] or performing other operations
        // For example, you might display a welcome message using the user's name:
        $welcome_message = "Welcome back, " . $user_data['username'] . "!";
    } else {
        // Handle the case when user is not logged in
        // For example, you might redirect the user to the login page:
        header("Location: Login.php");
        exit(); // Terminate script execution after redirection
    }

    if (!empty($username) && !empty($password) && !is_numeric($username)) {
        // Read from database
        $query = "SELECT * FROM login WHERE username = '$username' LIMIT 1";
        $result = mysqli_query($con, $query);

        if ($result) {
            $user_data = mysqli_fetch_assoc($result);
            if (password_verify($password, $user_data['password'])) {
                $_SESSION['username'] = $user_data['username'];
                $_SESSION['user_id'] = $user_data['user_id'];
                // Set other session variables as needed
                header("Location: ../dashbord.php");
                exit; // Exit after redirection to prevent further execution
            } else {
                echo "Invalid password";
            }
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Please enter some valid information!";
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePass - Login</title>
    <link rel="stylesheet" href="CSS/login.css">
</head>
<body>
    <div class="container">
        <form class="login-form" action = "actions/login_action.php" method = "post">
            <h2>Login to SecurePass</h2>
            <div class="input-group">
                <label for="username">Username or Email:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="input-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Login</button>
            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </form>
    </div>
</body>
</html>
