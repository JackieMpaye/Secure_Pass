$(document).ready(function () {
    // Handle form submission for changing password
    $('form.change-password-form').submit(function (event) {
        event.preventDefault();

        var currentPassword = $('#current-password').val();
        var newPassword = $('#new-password').val();
        var confirmPassword = $('#confirm-password').val();

        // Perform client-side validation
        if (newPassword !== confirmPassword) {
            alert('New password and confirm password do not match');
            return;
        }

        // Send AJAX request to change_password.php
        $.ajax({
            url: 'change_password.php',
            method: 'POST',
            data: {
                currentPassword: currentPassword,
                newPassword: newPassword
            },
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    alert(response.message);
                    // Clear form fields after successful password change
                    $('#current-password, #new-password, #confirm-password').val('');
                } else {
                    alert(response.message);
                }
            },
            error: function () {
                alert('An error occurred while processing your request.');
            }
        });
    });

    // Handle click event for password generator
    $('.generate-password').click(function () {
        // Generate a random password
        var newPassword = Math.random().toString(36).slice(-10); // Example: "3b51v8pc9t"

        // Fill the new password field
        $('#new-password').val(newPassword);
        $('#confirm-password').val(newPassword);
    });
});
