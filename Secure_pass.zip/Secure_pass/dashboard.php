<?php
// Ensure session is started before any output
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(); // Terminate script execution after redirection
}

// Include the database connection
include("settings/connection.php");

$user_id = $_SESSION['user_id'];

// Prepare SQL query to fetch passwords for the logged-in user
$sql = "SELECT website_name, username FROM passwords WHERE user_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die('Failed to prepare SQL query: ' . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePass - Dashboard</title>
    <link rel="stylesheet" href="CSS/dashboard.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <nav class="navbar">
        <div class="container">
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="passwords.php"><i class="fas fa-key"></i> Manage Passwords</a></li>
                <li><a href="settings.html"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h1>Welcome to Your SecurePass Dashboard</h1>

        <section class="passwords-section">
            <h2>Passwords</h2>
            <div id="passwords-container">
                <?php
                if ($result) {
                    while ($row = $result->fetch_assoc()) {
                        // Extract domain name from URL
                        $domain = parse_url($row["website_name"], PHP_URL_HOST);

                        echo '<div class="password-item">';
                        echo '<a href="verification.php?website=' . urlencode($row["website_name"]) . '" class="website-link">' . htmlspecialchars($domain) . '</a>';

                        echo '<div class="credentials-section" style="display:none;">';
                        echo '<p class="website-entry">Website: <span class="website-value">' . htmlspecialchars($row["website_name"]) . '</span></p>';
                        echo '<p class="username-entry">Username: <span class="username-value">' . htmlspecialchars($row["username"]) . '</span></p>';
                        echo '<p class="password-entry">Password: <span class="password-value">**********</span></p>';
                        echo '</div>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>No passwords found.</p>';
                }
                ?>
            </div>
        </section>

        <section class="settings-section">
            <h2>Settings</h2>
            <p>You can customize your account settings and security preferences.</p>
        </section>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</body>

</html>
