document.addEventListener('DOMContentLoaded', function () {
    const includeUppercaseCheckbox = document.getElementById('include-uppercase');
    const includeLowercaseCheckbox = document.getElementById('include-lowercase');
    const includeNumbersCheckbox = document.getElementById('include-numbers');
    const includeSymbolsCheckbox = document.getElementById('include-symbols');
    const passwordLengthInput = document.getElementById('password-length');
    const generateButton = document.getElementById('generate-password');
    const copyToClipboardButton = document.getElementById('copy-to-clipboard');
    const generatedPasswordInput = document.getElementById('generated-password');

    generateButton.addEventListener('click', function () {
        const passwordOptions = {
            uppercase: includeUppercaseCheckbox.checked,
            lowercase: includeLowercaseCheckbox.checked,
            numbers: includeNumbersCheckbox.checked,
            symbols: includeSymbolsCheckbox.checked,
            length: parseInt(passwordLengthInput.value)
        };

        const generatedPassword = generatePassword(passwordOptions);
        generatedPasswordInput.value = generatedPassword;

        copyToClipboardButton.disabled = false;
    });

    copyToClipboardButton.addEventListener('click', function () {
        generatedPasswordInput.select();
        document.execCommand('copy');
        alert('Password copied to clipboard!');
    });

    function generatePassword(options) {
        const charset = {
            uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
            lowercase: 'abcdefghijklmnopqrstuvwxyz',
            numbers: '0123456789',
            symbols: '!@#$%^&*()_-+=<>?'
        };

        let characters = '';

        for (let option in options) {
            if (options[option]) {
                characters += charset[option];
            }
        }

        let generatedPassword = '';
        for (let i = 0; i < options.length; i++) {
            const randomIndex = Math.floor(Math.random() * characters.length);
            generatedPassword += characters[randomIndex];
        }

        return generatedPassword;
    }
});
z