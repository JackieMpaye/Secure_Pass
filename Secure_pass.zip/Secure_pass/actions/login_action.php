<?php
session_start();
include("../settings/connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get username or email and password from the form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Query to retrieve user data based on username or email
    $query = "SELECT * FROM users WHERE username = ? OR email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // User found, verify password
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password_hash'])) {
            // Password is correct, store user data in session
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            
            // Redirect to dashboard or homepage
            header("Location: ../dashboard.php");
            exit();
        } else {
            // Password is incorrect
            echo "Incorrect password. Please try again.";
        }
    } else {
        // User not found
        echo "User not found. Please check your username or email.";
    }

    // Close database connection
    $stmt->close();
    $conn->close();
}
