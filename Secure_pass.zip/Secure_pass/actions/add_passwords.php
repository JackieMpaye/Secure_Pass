<?php
session_start(); // Start session to access session variables

include("../settings/connection.php");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access");
}

$user_id = $_SESSION['user_id'];

// Handle form submission to add or update password
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $website = $_POST['website'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert or update password in the database
    $stmt = $conn->prepare("INSERT INTO passwords (user_id, website_name, username, password) VALUES (?, ?, ?, ?)
                            ON DUPLICATE KEY UPDATE username = VALUES(username), password = VALUES(password)");

    $stmt->bind_param("isss", $user_id, $website, $username, $hashed_password);

    if ($stmt->execute()) {
        // Password added or updated successfully
        echo "<script>alert('Password added or updated successfully'); window.location.href = '../passwords.php';</script>";
    } else {
        // Error occurred while executing SQL statement
        echo "<script>alert('Failed to add or update password');</script>";
    }

    $stmt->close();
}

$conn->close();
?>
