<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Include Composer's autoloader
include "settings/connection.php"; // Include your database connection file

// Create a new PHPMailer instance
$mail = new PHPMailer(true);

try {
    // Generate a random verification code (you can customize the length as needed)
    $verificationCode = generateRandomCode(6); // Example: 6-digit verification code

    // Fetch user's email and name from the database based on username or user ID
    $username = $_SESSION['username']; // Assuming you have stored the username in the session
    $stmt = $conn->prepare("SELECT email FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($email);
        $stmt->fetch();

        //Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'your-gmail@gmail.com'; // Your Gmail email address
        $mail->Password   = 'your-gmail-password'; // Your Gmail password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        //Recipients
        $mail->setFrom('noreply@securepass.com', 'SecurePass');
        $mail->addAddress($email, $username); // Use the user's email and username fetched from the database

        //Content
        $mail->isHTML(true);
        $mail->Subject = 'SecurePass Verification Code';
        $mail->Body    = 'Your verification code for SecurePass is: <strong>' . $verificationCode . '</strong>';

        // Send the email
        $mail->send();
        echo 'Verification code has been sent successfully!';
        
        // Store the verification code in the session for validation later
        $_SESSION['verification_code'] = $verificationCode;
    } else {
        echo 'User not found.';
    }

    $stmt->close();
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

// Function to generate a random verification code
function generateRandomCode($length = 6) {
    $characters = '0123456789';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $code;
}

