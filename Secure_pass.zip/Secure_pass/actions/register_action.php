<?php
 include("../settings/connection.php");
// Check if the form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection file
   

    // Get form data
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    // Hash the password securely
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and execute SQL statement to insert user data into the database
    $sql = "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $username, $email, $hashed_password);
    
    if ($stmt->execute()) {
        // User registration successful
        header("Location: ../Homepage.html");
    } else {
        // Error occurred during registration
        echo "Error: " . $conn->error;
    }
}
    // Close database connection
    $stmt->close();
    $conn->close();

