<?php
session_start(); // Start session to access session variables

if (!isset($_SESSION['user_id'])) {
    // Redirect if user is not logged in
    echo 'invalid'; // No user session available, return 'invalid'
    exit();
}

include("../settings/connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $password = $_POST['password'];

    // Prepare SQL query to fetch user's password hash
    $stmt = $conn->prepare("SELECT password_hash FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($password_hash);
        $stmt->fetch();

        // Verify entered password with the stored password hash
        if (password_verify($password, $password_hash)) {
            // Password matches, return 'valid'
            echo 'valid';
        } else {
            // Password does not match, return 'invalid'
            echo 'invalid';
        }
    } else {
        // User not found, return 'invalid'
        echo 'invalid';
    }

    // Close prepared statement
    $stmt->close();
    $conn->close();
} else {
    // Invalid request method
    echo 'invalid';
}
