<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - SecurePass</title>

    <style>
        /* Style for body */
body {
    font-family: Arial, sans-serif;
    background-color: #f5f5f5;
    margin: 0;
    padding: 0;
}

/* Container styles */
.container {
    max-width: 600px;
    margin: 50px auto;
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* Heading styles */
h2 {
    text-align: center;
    color: #333333;
}

/* Form styles */
form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 8px;
    color: #555555;
}

input[type="email"],
input[type="text"] {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #cccccc;
    border-radius: 4px;
    box-sizing: border-box;
}

button {
    display: block;
    width: 100%;
    padding: 10px;
    margin-top: 20px;
    background-color: #007bff;
    color: #ffffff;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

/* Verification code section */
#verification-code-section {
    max-width: 400px;
    margin: 100px auto;
    background-color: #fff;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

#verification-code-section h3 {
    margin-bottom: 10px;
}

/* Responsive design */
@media (max-width: 768px) {
    .container {
        padding: 10px;
    }
}

    </style>
</head>

<body>
    <h2>Forgot Password</h2>
     

    <div id="verification-code-section">
        <h3>Verification Code</h3>
        <p>An email with a verification code has been sent to your email address.</p>
        <p><a href="actions/send-email.php"> not seeing code? request again</p>
        <form id="verify-code-form">
            <label for="verification-code">Enter Verification Code:</label>
            <input type="text" id="verification-code" name="verification-code" required>
            <button type="submit">Verify Code</button>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            // Handle form submission for sending verification code
            $('#forgot-password-form').submit(function (e) {
                e.preventDefault();

                var email = $('#email').val();

                $.ajax({
                    method: 'POST',
                    url: 'actions/send-email.php', // Create this file to handle sending the verification code
                    data: { email: email },
                    success: function (response) {
                        $('#forgot-password-form').hide();
                        $('#verification-code-section').show();
                    },
                    error: function () {
                        alert('Failed to send verification code. Please try again.');
                    }
                });
            });
        
            // Handle form submission for verifying code
            $('#verify-code-form').submit(function (e) {
                e.preventDefault();

                var code = $('#verification-code').val();

                $.ajax({
                    method: 'POST',
                    url: 'verify-code.php',
                    data: { code: code },
                    success: function (response) {
                        if (response === 'valid') {
                            window.location.href = 'view_password.php';
                        } else {
                            alert('Invalid verification code. Please try again.');
                        }
                    },
                    error: function () {
                        alert('Failed to verify code. Please try again.');
                    }
                });
            });
        });
    </script>
</body>

</html>





