<?php
// Ensure session is started before any output
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(); // Terminate script execution after redirection
}

// Include the database connection
include("settings/connection.php");

$user_id = $_SESSION['user_id'];

// Retrieve the website name from the query string
$website_name = isset($_GET['website']) ? $_GET['website'] : '';

// Prepare SQL query to fetch the username associated with the user_id (optional)
$stmt = $conn->prepare("SELECT username FROM users WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->bind_result($username);
    $stmt->fetch();
} else {
    $username = ''; // Default username if not found
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePass - Verification</title>
    <link rel="stylesheet" href="CSS/verification.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <div class="verification-container">
        <div class="verification-form">
            <h2>Hi <?php echo isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : ''; ?></h2>
            <p><?php echo isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : ''; ?></p>
            <div class="verification-input">
                <label for="password">To continue, please verify your identity:</label>
                <form id="verification-form">
                    <div class="password-input-container">
                        <input type="password" id="password" name="password" placeholder="Enter your password" required>
                        <span class="toggle-password" onclick="togglePasswordVisibility()">
                            <i class="far fa-eye" id="password-eye"></i>
                        </span>
                    </div>
                    <button type="submit">Verify</button>
                </form>
            </div>
            <p><a href="forgot_password.php">Forgot Password?</a></p>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        function togglePasswordVisibility() {
            var passwordInput = document.getElementById("password");
            var passwordEye = document.getElementById("password-eye");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                passwordEye.classList.remove("fa-eye");
                passwordEye.classList.add("fa-eye-slash");
            } else {
                passwordInput.type = "password";
                passwordEye.classList.remove("fa-eye-slash");
                passwordEye.classList.add("fa-eye");
            }
        }

        // Handle form submission
        $('#verification-form').submit(function (e) {
            e.preventDefault(); // Prevent default form submission

            var password = $('#password').val();

            // Make AJAX request to verify password
            $.ajax({
                method: 'POST',
                url: 'actions/verify.php',
                data: {
                    websiteName: '<?php echo urlencode($website_name); ?>',
                    password: password
                },
                success: function (response) {
                    if (response === 'valid') {
                        // Password is valid, redirect to view password page
                        window.location.href = 'view_passwords.php?website=<?php echo urlencode($website_name); ?>';
                    } else {
                        alert('Invalid password. Please try again.');
                    }
                },
                error: function () {
                    alert('Error occurred. Please try again.');
                }
            });
        });
    </script>
</body>

</html>
