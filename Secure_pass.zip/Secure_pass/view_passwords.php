<?php
// Ensure session is started before any output
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(); // Terminate script execution after redirection
}

// Include the database connection
include("settings/connection.php");

$user_id = $_SESSION['user_id'];

// Retrieve the website name from the query string
$website_name = isset($_GET['website']) ? $_GET['website'] : '';

// Prepare SQL query to fetch the password details
$stmt = $conn->prepare("SELECT * FROM passwords WHERE user_id = ? AND website_name = ?");
$stmt->bind_param("is", $user_id, $website_name);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $password_details = $result->fetch_assoc();
} else {
    // Redirect to passwords.php if password not found
    header("Location: passwords.php");
    exit();
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Password - SecurePass</title>
    <link rel="stylesheet" href="path/to/view-password.css">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <div class="container">
        <h2>Password Details</h2>
        <div class="password-container">
            <label for="password">Password:</label>
            <div class="password-input-container">
                <input type="password" id="password" name="password" value="<?php echo htmlspecialchars($password_details['password']); echo urlencode($password_details['website_name']); ?>" readonly>
                <span class="toggle-password" onclick="togglePasswordVisibility()">
                    <i class="far fa-eye" id="password-eye"></i>
                </span>
            </div>
        </div>
        <div class="buttons">
            <?php if (isset($_SESSION['user_id'])) : ?>
                <a href="edit_password.php?website=<?php echo urlencode($password_details['website_name']); echo htmlspecialchars($password_details['password']);?>" class="edit-btn">
                    <button>Edit</button>
                </a>
                <button onclick="confirmDelete('<?php echo $password_details['website_name']; ?>')" class="delete-btn">
                    Delete
                </button>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="path/to/view-password.js"></script>
    <script>
        function togglePasswordVisibility() {
            var passwordInput = document.getElementById("password");
            var passwordEye = document.getElementById("password-eye");

            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                passwordEye.classList.remove("fa-eye");
                passwordEye.classList.add("fa-eye-slash");
            } else {
                passwordInput.type = "password";
                passwordEye.classList.remove("fa-eye-slash");
                passwordEye.classList.add("fa-eye");
            }
        }

        function confirmDelete(websiteName) {
            if (confirm(`Are you sure you want to delete the password for ${websiteName}?`)) {
                window.location.href = `delete_password.php?website=${encodeURIComponent(websiteName)}`;
            }
        }
    </script>
</body>

</html>
