<?php
session_start();

function check_login() {
    if (!isset($_SESSION['pid']) || empty($_SESSION['pid']) || !isset($_SESSION['rid']) || empty($_SESSION['rid'])) {
        header("Location: ../Login/Log-in_view.php");
        die(); // Terminate script execution after redirection
    } else {
        return $_SESSION['rid'];
    }
}

