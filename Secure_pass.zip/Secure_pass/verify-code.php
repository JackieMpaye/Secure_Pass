<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['code'])) {
        $user_code = $_POST['code'];

        // Retrieve the stored verification code from the session
        $verification_code = isset($_SESSION['verification_code']) ? $_SESSION['verification_code'] : '';

        // Compare the entered code with the stored verification code
        if ($user_code == $verification_code) {
            // Verification successful
            echo "valid";
        } else {
            // Verification failed
            echo "invalid";
        }
    } else {
        echo "Verification code parameter is missing.";
    }
} else {
    echo "Invalid request method.";
}
