<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include("settings/connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['deletePassword'])) {
        $user_id = $_SESSION['user_id'];
        $delete_password = $_POST['deletePassword'];

        $stmt = $conn->prepare("SELECT password_hash FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($password_hash);
            $stmt->fetch();

            if (password_verify($delete_password, $password_hash)) {
                $delete_sql = "DELETE FROM users WHERE user_id = ?";
                $delete_stmt = $conn->prepare($delete_sql);

                if (!$delete_stmt) {
                    die('Failed to prepare SQL query: ' . $conn->error);
                }

                $delete_stmt->bind_param("i", $user_id);
                $delete_stmt->execute();
                $delete_stmt->close();

                session_unset();
                session_destroy();
                header("Location: logout.php");
                exit();
            } else {
                echo "Invalid password for account deletion.";
            }
        } else {
            echo "User not found.";
        }

        $stmt->close();
    } else {
        echo "Invalid request.";
    }
} else {
    echo "Invalid request method.";
}
?>
