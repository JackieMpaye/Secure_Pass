<?php
// Ensure session is started at the beginning
session_start();

include("settings/connection.php");

// Initialize variables to store form data and errors
$website = $username = $password = '';
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize form input
    $website = test_input($_POST['website']);
    $username = test_input($_POST['username']);
    $password = test_input($_POST['password']);

    // Insert data into database if no validation errors
    if (empty($errors)) {
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];

            // Prepare SQL statement to insert data into passwords table
            $stmt = $conn->prepare("INSERT INTO passwords (user_id, website, username, password) VALUES (?, ?, ?, ?)");

            if ($stmt) {
                // Bind parameters to the prepared statement
                $stmt->bind_param("isss", $user_id, $website, $username, $password);

                // Execute the prepared statement
                if ($stmt->execute()) {
                    // Redirect to passwords page or display success message
                    header("Location: passwords.php");
                    exit();
                } else {
                    $errors[] = "Error executing SQL statement: " . $stmt->error;
                }
            } else {
                $errors[] = "Error preparing SQL statement: " . $conn->error;
            }
        } else {
            $errors[] = "User ID not set";
        }
    }
}




// Function to sanitize form input
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePass - Password Management</title>
    <link rel="stylesheet" href="CSS/passwords.css">
    <script>
        // JavaScript function to validate website URL
        function validateForm() {
            var websiteInput = document.getElementById('website');
            var websiteValue = websiteInput.value.trim();

            // Regular expression pattern to validate URL
            var urlPattern = /^(https?:\/\/)?([\w\-]+(\.[\w\-]+)+\/?|localhost(:\d+)?)([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?$/;

            // Check if the entered value matches the URL pattern
            if (!urlPattern.test(websiteValue)) {
                alert("Invalid website URL. Please enter a valid URL (e.g., https://example.com).");
                websiteInput.focus(); // Set focus back to website input field
                return false; // Prevent form submission
            }

            return true; // Allow form submission if URL is valid
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Manage Your Passwords</h2>
        
        <button class="add-password-btn" onclick="document.getElementById('password-form-container').style.display='block';">Add New Password</button>

        <!-- Form for adding/editing passwords -->
        <div id="password-form-container" style="display: none;">
            <h2>Add/Edit Password</h2>
            <p><a href ="dashboard.php"> back to dashboard</p>
            <form id="password-form" action="actions/add_passwords.php" method="post" onsubmit="return validateForm();">
                <label for="website">Website:</label>
                <input type="text" id="website" name="website" required>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <button type="submit">Save Password</button>
                <button type="button" onclick="document.getElementById('password-form-container').style.display='none';">Cancel</button>
            </form>
        </div>
    </div>
</body>
</html>


    <!-- JavaScript for password management -->
    <script src="passwords.js"></script>
    <script>
        function showPasswordForm() {
            document.getElementById('password-form-container').style.display = 'block';
        }

        function hidePasswordForm() {
            document.getElementById('password-form-container').style.display = 'none';
        }
    </script>
</body>
</html>
