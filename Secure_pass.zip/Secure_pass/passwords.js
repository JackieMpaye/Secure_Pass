// Mock data for initial passwords (replace with actual data from backend)
let passwords = [
    { id: 1, website: "example.com", username: "user1", password: "password1" },
    { id: 2, website: "example.org", username: "user2", password: "password2" }
];

// Function to populate the password list
function populatePasswordList() {
    const passwordList = document.getElementById("password-list");
    passwordList.innerHTML = "";

    passwords.forEach(password => {
        const listItem = document.createElement("li");
        listItem.innerHTML = `
            <strong>Website:</strong> ${password.website} | 
            <strong>Username:</strong> ${password.username} | 
            <strong>Password:</strong> ${password.password}
            <button onclick="deletePassword(${password.id})">Delete</button>
        `;
        passwordList.appendChild(listItem);
    });
}

// Function to add or edit password
function savePassword(event) {
    event.preventDefault();
    const website = document.getElementById("website").value;
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    // Check if adding or editing
    const passwordId = parseInt(document.getElementById("password-id").value);
    if (passwordId) {
        // Editing existing password
        const existingPassword = passwords.find(password => password.id === passwordId);
        if (existingPassword) {
            existingPassword.website = website;
            existingPassword.username = username;
            existingPassword.password = password;
        }
    } else {
        // Adding new password
        const newPassword = {
            id: passwords.length + 1,
            website: website,
            username: username,
            password: password
        };
        passwords.push(newPassword);
    }

    // Clear form fields
    document.getElementById("password-form").reset();
    document.getElementById("password-id").value = "";

    // Repopulate password list
    populatePasswordList();
}

// Function to delete password
function deletePassword(passwordId) {
    passwords = passwords.filter(password => password.id !== passwordId);
    populatePasswordList();
}

// Function to populate form fields for editing
function editPassword(passwordId) {
    const password = passwords.find(password => password.id === passwordId);
    if (password) {
        document.getElementById("website").value = password.website;
        document.getElementById("username").value = password.username;
        document.getElementById("password").value = password.password;
        document.getElementById("password-id").value = passwordId;
    }
}

// Initialize - Populate password list
populatePasswordList();

// Event listener for password form submission
document.getElementById("password-form").addEventListener("submit", savePassword);
