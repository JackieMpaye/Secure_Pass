<?php

include("settings/connection.php");

session_start();

$user_id = $_SESSION['user_id'];
// Prepare and execute a query to fetch the user's email address
$stmt = $conn->prepare("SELECT email FROM users WHERE user_id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$stmt->bind_result($email);
$stmt->fetch();
$stmt->close();

if ($email) {
    // Generate a random verification code (e.g., a 6-digit number)
    $verificationCode = mt_rand(100000, 999999);

    // Compose the email message
    $subject = 'Verification Code for Password Reset';
    $message = 'Your verification code is: ' . $verificationCode;
    $headers = 'From: jacklinempaye@gmail.com'; // Replace with a valid sender email address

    // Send the email and handle errors
    if (mail($email, $subject, $message, $headers)) {
        echo "Verification code sent successfully.";

        // Store the verification code in the session for validation later
        session_start();
        $_SESSION['verification_code'] = $verificationCode;
        $_SESSION['email'] = $email;
    } else {
        echo "Failed to send verification code.";
        error_log("Email sending failed.");
    }
} else {
    echo "User not found.";
}

