<?php
// Ensure session is started
session_start();


// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Other PHP code follows...


// Include database connection
include("settings/connection.php");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if user is not logged in
    header("Location: login.php");
    exit();
}

// Retrieve user_id from session
$user_id = $_SESSION['user_id'];

// Validate incoming POST data
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $currentPassword = $_POST['current-password'];
    $newPassword = $_POST['new-password'];
    $confirmPassword = $_POST['confirm-password'];

    // Retrieve current password hash from the database
    $stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->store_result();

    // Check if user exists
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($storedPassword);
        $stmt->fetch();

        // Verify current password
        if (password_verify($currentPassword, $storedPassword)) {
            // Current password is correct, proceed with password change
            if ($newPassword === $confirmPassword) {
                // Hash the new password
                $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

                // Update the user's password in the database
                $updateStmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $updateStmt->bind_param("si", $newPasswordHash, $user_id);

                if ($updateStmt->execute()) {
                    // Password updated successfully
                    echo 'success';
                } else {
                    // Password update failed
                    echo 'error';
                }
            } else {
                // New password and confirm password do not match
                echo 'password_mismatch';
            }
        } else {
            // Current password is incorrect
            echo 'incorrect_password';
        }
    } else {
        // User not found (should not happen if user is logged in)
        echo 'user_not_found';
    }

    // Close statements and database connection
    $stmt->close();
    $updateStmt->close();
    $conn->close();
} else {
    // Redirect to settings page if accessed directly
    header("Location: settings.php");
    exit();
}
?>
