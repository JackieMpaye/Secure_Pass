<?php
include("settings/connection.php"); // Include database connection file
//include("../settings/functions.php");
//include("../settings/core.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_user_name = $_POST['user_name'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    if (!empty($_user_name) && !empty($password)  && !empty($email) && !is_numeric($_user_name)) {
        $user_id = random_num(20);
        $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash the password securely

        $query = "INSERT INTO login (user_id, user_name, email, password) VALUES ('$user_id', '$_user_name', '$email', '$hashed_password') ";

        mysqli_query($con, $query);

        header("Location: ../view_folder/Homepage.html");
        die;
    } else {
        echo "Please enter some valid information!";
    }
}
?>







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecurePass - Register</title>
    <link rel="stylesheet" href="CSS/register.css">
</head>
<body>
    <div class="container">
        <form class="register-form" action = "actions/register_action.php" method = "post" onsubmit = "return validateForm()">
            <h2>Create an Account</h2>
            <div class="input-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="input-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="input-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="input-group">
                <label for="confirmpassword">Confirm Password</label>
                <input type="password" id="confirmpassword" name="confirmpassword" required><br>
            </div>
            <button type="submit">Register</button>
            <p>Already have an account? <a href="login.html">Login here</a></p>
        </form>
    </div>

    <script>
        function validateForm() {
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        const confirmPassword = document.getElementById("confirmpassword").value;

        const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;

        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address");
            return false;
        }

        if (password !== confirmPassword) {
            alert("Passwords do not match");
            return false;
        }

        // If validation succeeds, redirect to homepage
        redirectToHomePage();
        return true;
    }

    function redirectToHomePage() {
        window.location.href = "Homepage.html";
    }
    </script>
</body>
</html>

?>
